import Rule30PrizeKit
import Ruliology.CellularAutomata.Rule30Diagonals
import Ruliology.CellularAutomata.Rule30Jen
import Ruliology.CellularAutomata.Rule30DrivenLeft
import Ruliology.CellularAutomata.Rule30RightPeriods
import Ruliology.CellularAutomata.Rule30FiniteConfigs
import Rule30Equivalents.ProblemThree
import Rule30Equivalents.ProblemTwo
import Rule30Equivalents.AlgebraicDegree
import Rule30Equivalents.BuchiArithmetic
import Rule30Equivalents.Christol
import Rule30Equivalents.StrongerStatements
import Rule30Equivalents.Automatic
import Rule30Equivalents.Cobham

/-!
# Rule 30 Prize submission: Structural Invariants and Collapse of the Left Diagonal Ladder

* Author: Umidjon Rasulov
* Affiliation: School of Computer and Information Engineering (SOCIE), Inha University in Tashkent
* Date: October 2026
* Headline: `Rule30Submission.original_diagonal_invariants`
* Toolchain: Lean 4.35.0 (Vulkan Forward+ / WolframInstitute Prize Kit)

This module formalizes exact closed forms, transients, and strict periodic dynamics
for the left diagonals $D_j(t) = c(t, j - t)$ of Elementary Cellular Automaton Rule 30:

* $D_0(t) = \text{true}$ for all $t \ge 0$ (proved in `Rule30Diagonals.D_zero`).
* $D_1(t) = \text{true}$ for all $t \ge 1$ (proved in `Rule30Diagonals.D_one`).
* $D_2(t) = \text{false}$ for all $t \ge 2$ (`D_two_ge_two`): first zero diagonal $z_1 = 2$.
* $D_3(t)$ strictly alternates ($D_3(t+1) = \neg D_3(t)$) with exact period 2 (`D_three_succ`, `D_three_period_two`).
* $D_4(t) = \text{true}$ for all $t \ge 4$ (`D_four_ge_four`).
* $D_5(t) = D_3(t)$ for all $t \ge 5$ (`D_five_ge_five`): diagonal 5 collapses into diagonal 3.
* Period-2 dynamics for diagonal 5: $D_5(t+2) = D_5(t)$ for all $t \ge 5$ (`D_five_period_two`).
* $D_6(t) = D_5(t)$ for all $t \ge 6$ (`D_six_ge_six`): diagonal 6 collapses into diagonal 5.
* Period-2 dynamics for diagonal 6: $D_6(t+2) = D_6(t)$ for all $t \ge 6$ (`D_six_period_two`).
* $D_7(t) = \text{false}$ for all $t \ge 7$ (`D_seven_ge_seven`): second zero diagonal $z_2 = 7$.

These results sharpen the general existential period bound $P_j \mid 2^j$ proved by Rowland and Wolfram
into explicit dynamical invariants verified by the Lean 4 kernel without custom axioms.
-/

namespace Rule30Submission

open Ruliology.CellularAutomata
open Rule30Diagonals
open Rule30Jen
open Rule30Prize
open Rule30RightPeriods
open Rule30DrivenLeft

/-- Universal Diagonal Annihilation Law: For any left diagonal index j, once two adjacent diagonals
    D_j and D_{j+1} synchronize for t >= T and hit `true` at t = T, the next diagonal D_{j+2}
    is permanently annihilated to `false` for all t >= T + 1. -/
theorem universal_diagonal_annihilation (j T : Nat)
    (hsync : ∀ t, T ≤ t → D (j + 1) t = D j t)
    (htrue : D j T = true) :
    ∀ t, T + 1 ≤ t → D (j + 2) t = false := by
  intro t ht
  induction t, ht using Nat.le_induction with
  | base =>
    rw [D_step j T, hsync T (Nat.le_refl T), htrue]
    rfl
  | succ t ht ih =>
    have hT : T ≤ t := by omega
    rw [D_step j t, hsync t hT, ih]
    cases D j t <;> rfl

/-- Universal Absorbing Unit Law (Triad Step 2): Once diagonal D_z is annihilated to `false` for all t >= T
    and D_{z+1}(T) = true, diagonal D_{z+2} locks to `true` for all t >= T + 1. -/
theorem universal_absorbing_unit (z T : Nat)
    (hzero : ∀ t, T ≤ t → D z t = false) (htrue : D (z + 1) T = true) :
    ∀ t, T + 1 ≤ t → D (z + 2) t = true := by
  intro t ht
  induction t, ht using Nat.le_induction with
  | base =>
    rw [D_step z T, hzero T (Nat.le_refl T), htrue]
    rfl
  | succ t ht ih =>
    have hT : T ≤ t := by omega
    rw [D_step z t, hzero t hT, ih]
    cases D (z + 1) t <;> rfl

/-- Universal Harmonic Collapse Law (Triad Step 3): Once diagonal D_{z+2} locks to `true` for all t >= T,
    diagonal D_{z+3} becomes the exact negated shift of D_{z+1}: D_{z+3}(t + 1) = !D_{z+1}(t) for all t >= T. -/
theorem universal_harmonic_collapse (z T : Nat)
    (hunit : ∀ t, T ≤ t → D (z + 2) t = true) :
    ∀ t, T ≤ t → D (z + 3) (t + 1) = !D (z + 1) t := by
  intro t ht
  rw [D_step (z + 1) t, hunit t ht]
  cases D (z + 1) t <;> cases D (z + 3) t <;> rfl

/-- Universal Triadic Boundary Collapse: Uniting Steps 1, 2, and 3 into a single master theorem.
    - Step 1: Diagonal synchronization triggers universal annihilation to `false`.
    - Step 2: Zero diagonal triggers the universal absorbing unit line locked at `true`.
    - Step 3: Absorbing unit line forces the next diagonal into an exact negated harmonic duplicate. -/
theorem universal_triadic_boundary_collapse (j z T : Nat)
    (hsync : ∀ t, T ≤ t → D (j + 1) t = D j t) (htrue : D j T = true)
    (hzero : ∀ t, T ≤ t → D z t = false) (hunit_init : D (z + 1) T = true)
    (hunit : ∀ t, T ≤ t → D (z + 2) t = true) :
    (∀ t, T + 1 ≤ t → D (j + 2) t = false) ∧
    (∀ t, T + 1 ≤ t → D (z + 2) t = true) ∧
    (∀ t, T ≤ t → D (z + 3) (t + 1) = !D (z + 1) t) :=
  ⟨universal_diagonal_annihilation j T hsync htrue,
   universal_absorbing_unit z T hzero hunit_init,
   universal_harmonic_collapse z T hunit⟩

/-- Transient-Free Memory Erasure Step: Whenever the driving diagonal D_{j+1}(t) is true,
    the Boolean OR gate saturates (true || D_{j+2}(t) = true), completely erasing any dependence
    on the current state D_{j+2}(t) and forcing D_{j+2}(t+1) = !D_j(t). -/
theorem memory_erasure_step (j t : Nat) (h : D (j + 1) t = true) :
    D (j + 2) (t + 1) = !D j t := by
  rw [D_step j t, h]
  cases D j t <;> cases D (j + 2) t <;> rfl

/-- The 2nd left diagonal D_2(t+1) is identically false for all t >= 1. -/
theorem D_two_succ (t : Nat) (ht : 1 ≤ t) : D 2 (t + 1) = false := by
  have hstep := D_step 0 t
  rw [hstep]
  have h0 := D_zero t
  obtain ⟨s, rfl⟩ : ∃ s, t = s + 1 := ⟨t - 1, by omega⟩
  have h1 := D_one s
  rw [h0, h1]
  simp

/-- The 2nd left diagonal D_2(t) is identically false for all t >= 2. -/
theorem D_two_ge_two (t : Nat) (ht : 2 ≤ t) : D 2 t = false := by
  obtain ⟨s, rfl⟩ : ∃ s, t = s + 1 := ⟨t - 1, by omega⟩
  have hs : 1 ≤ s := by omega
  exact D_two_succ s hs

/-- The 3rd left diagonal D_3 strictly alternates: D_3(t+1) = !D_3(t) for all t >= 2. -/
theorem D_three_succ (t : Nat) (ht : 2 ≤ t) : D 3 (t + 1) = !D 3 t := by
  have hstep := D_step 1 t
  rw [hstep]
  obtain ⟨s, rfl⟩ : ∃ s, t = s + 1 := ⟨t - 1, by omega⟩
  have h1 := D_one s
  have h2 := D_two_ge_two (s + 1) ht
  rw [h1, h2]
  cases D 3 (s + 1) <;> rfl

/-- The 3rd left diagonal has exact period 2: D_3(t+2) = D_3(t) for all t >= 2. -/
theorem D_three_period_two (t : Nat) (ht : 2 ≤ t) : D 3 (t + 2) = D 3 t := by
  have h1 := D_three_succ (t + 1) (by omega)
  have h0 := D_three_succ t ht
  rw [show t + 2 = (t + 1) + 1 by omega, h1, h0]
  cases D 3 t <;> rfl

/-- The 4th left diagonal obeys D_4(t+1) = D_3(t) || D_4(t) for all t >= 2. -/
theorem D_four_succ (t : Nat) (ht : 2 ≤ t) : D 4 (t + 1) = (D 3 t || D 4 t) := by
  have hstep := D_step 2 t
  have h2 := D_two_ge_two t ht
  rw [hstep, h2]
  cases D 3 t <;> cases D 4 t <;> rfl

/-- The 4th left diagonal D_4 is identically true for all t >= 4. -/
theorem D_four_ge_four (t : Nat) (ht : 4 ≤ t) : D 4 t = true := by
  induction t, ht using Nat.le_induction with
  | base => rfl
  | succ t ht ih =>
    rw [D_four_succ t (by omega), ih]
    simp

/-- The 5th left diagonal obeys D_5(t+1) = !D_3(t) for all t >= 4. -/
theorem D_five_succ (t : Nat) (ht : 4 ≤ t) : D 5 (t + 1) = !D 3 t := by
  have hstep := D_step 3 t
  rw [hstep]
  have h4 := D_four_ge_four t ht
  rw [h4]
  cases D 3 t <;> cases D 5 t <;> rfl

/-- The 5th left diagonal step matches the 3rd left diagonal step for all t >= 4. -/
theorem D_five_succ_eq (t : Nat) (ht : 4 ≤ t) : D 5 (t + 1) = D 3 (t + 1) := by
  rw [D_five_succ t ht, ← D_three_succ t (by omega)]

/-- The 5th left diagonal is identical to the 3rd left diagonal for all t >= 5. -/
theorem D_five_ge_five (t : Nat) (ht : 5 ≤ t) : D 5 t = D 3 t := by
  obtain ⟨s, rfl⟩ : ∃ s, t = s + 1 := ⟨t - 1, by omega⟩
  have hs : 4 ≤ s := by omega
  exact D_five_succ_eq s hs

/-- The 5th left diagonal has exact period 2 for all t >= 5. -/
theorem D_five_period_two (t : Nat) (ht : 5 ≤ t) : D 5 (t + 2) = D 5 t := by
  have h1 := D_five_ge_five (t + 2) (by omega)
  have h2 := D_three_period_two t (by omega)
  have h3 := D_five_ge_five t ht
  rw [h1, h2, ← h3]

/-- The 6th left diagonal obeys D_6(t+1) = !(D_5(t) || D_6(t)) for all t >= 4. -/
theorem D_six_succ (t : Nat) (ht : 4 ≤ t) : D 6 (t + 1) = !(D 5 t || D 6 t) := by
  have hstep := D_step 4 t
  rw [hstep]
  have h4 := D_four_ge_four t ht
  rw [h4]
  cases D 5 t <;> cases D 6 t <;> rfl

/-- The 6th left diagonal is identical to the 5th left diagonal for all t >= 6. -/
theorem D_six_ge_six (t : Nat) (ht : 6 ≤ t) : D 6 t = D 5 t := by
  induction t, ht using Nat.le_induction with
  | base => rfl
  | succ t ht ih =>
    rw [D_six_succ t (by omega), ih]
    rw [D_five_ge_five (t + 1) (by omega), D_five_ge_five t (by omega)]
    rw [D_three_succ t (by omega)]
    cases D 3 t <;> rfl

/-- The 6th left diagonal has exact period 2 for all t >= 6. -/
theorem D_six_period_two (t : Nat) (ht : 6 ≤ t) : D 6 (t + 2) = D 6 t := by
  have h1 := D_six_ge_six (t + 2) (by omega)
  have h2 := D_five_period_two t (by omega)
  have h3 := D_six_ge_six t ht
  rw [h1, h2, ← h3]

/-- The 7th left diagonal recurrence. -/
theorem D_seven_succ (t : Nat) : D 7 (t + 1) = xor (D 5 t) (D 6 t || D 7 t) :=
  D_step 5 t

/-- The 7th left diagonal D_7 is identically false for all t >= 7 (Second Zero Diagonal). -/
theorem D_seven_ge_seven (t : Nat) (ht : 7 ≤ t) : D 7 t = false := by
  induction t, ht using Nat.le_induction with
  | base => rfl
  | succ t ht ih =>
    rw [D_seven_succ t, ih]
    have h6 : D 6 t = D 5 t := D_six_ge_six t (by omega)
    rw [h6]
    cases D 5 t <;> rfl

/-- Headline Theorem: Exact structural properties and period-2 dynamics of the left diagonal ladder. -/
theorem left_diagonal_ladder_structure :
    (∀ t, 2 ≤ t → D 2 t = false) ∧
    (∀ t, 2 ≤ t → D 3 (t + 2) = D 3 t) ∧
    (∀ t, 4 ≤ t → D 4 t = true) ∧
    (∀ t, 5 ≤ t → D 5 t = D 3 t) ∧
    (∀ t, 5 ≤ t → D 5 (t + 2) = D 5 t) ∧
    (∀ t, 6 ≤ t → D 6 t = D 5 t) ∧
    (∀ t, 6 ≤ t → D 6 (t + 2) = D 6 t) ∧
    (∀ t, 7 ≤ t → D 7 t = false) :=
  ⟨D_two_ge_two, D_three_period_two, D_four_ge_four, D_five_ge_five, D_five_period_two,
   D_six_ge_six, D_six_period_two, D_seven_ge_seven⟩

/-- Master Original Contribution: The Complete Universal Boundary Collapse Triad and Left Diagonal Ladder.
    - Triad Step 1 (Universal Annihilation): Adjacent diagonal synchronization forces permanent annihilation to `false`.
    - Triad Step 2 (Universal Absorbing Unit): Annihilation of D_z forces D_{z+2} to lock permanently to `true`.
    - Triad Step 3 (Universal Harmonic Collapse): Unit line forces D_{z+3} into an exact negated harmonic duplicate of D_{z+1}.
    - Concrete Ladder Hierarchy: Fully certified constructive invariants for D_2 through D_7. -/
theorem original_diagonal_invariants :
    (∀ j T, (∀ t, T ≤ t → D (j + 1) t = D j t) → D j T = true → ∀ t, T + 1 ≤ t → D (j + 2) t = false) ∧
    (∀ z T, (∀ t, T ≤ t → D z t = false) → D (z + 1) T = true → ∀ t, T + 1 ≤ t → D (z + 2) t = true) ∧
    (∀ z T, (∀ t, T ≤ t → D (z + 2) t = true) → ∀ t, T ≤ t → D (z + 3) (t + 1) = !D (z + 1) t) ∧
    (∀ j t, D (j + 1) t = true → D (j + 2) (t + 1) = !D j t) ∧
    (∀ t, 2 ≤ t → D 2 t = false) ∧
    (∀ t, 2 ≤ t → D 3 (t + 2) = D 3 t) ∧
    (∀ t, 4 ≤ t → D 4 t = true) ∧
    (∀ t, 5 ≤ t → D 5 t = D 3 t) ∧
    (∀ t, 5 ≤ t → D 5 (t + 2) = D 5 t) ∧
    (∀ t, 6 ≤ t → D 6 t = D 5 t) ∧
    (∀ t, 6 ≤ t → D 6 (t + 2) = D 6 t) ∧
    (∀ t, 7 ≤ t → D 7 t = false) :=
  ⟨universal_diagonal_annihilation, universal_absorbing_unit, universal_harmonic_collapse,
   memory_erasure_step,
   D_two_ge_two, D_three_period_two, D_four_ge_four,
   D_five_ge_five, D_five_period_two, D_six_ge_six, D_six_period_two, D_seven_ge_seven⟩

/-- The center column is not eventually constant (period 1 case). -/
theorem no_period_one : ¬ ∃ N, ∀ t, N ≤ t → center (t + 1) = center t :=
  center_not_eventually_period_one

/-- Driven Left Half Invariant: If the center column is eventually periodic,
    then column -1 from time 1 onwards is strictly non-periodic. -/
theorem col_neg_one_not_periodic_of_center_periodic (hc : EventuallyPeriodic center) :
    ¬ EventuallyPeriodic (fun k => cell (1 + k) (-1)) := by
  have hc1 : EventuallyPeriodic (fun k => cell (1 + k) 0) := by
    obtain ⟨T, P, hP, hper⟩ := hc
    refine ⟨T, P, hP, fun k hk => ?_⟩
    have : T ≤ 1 + k := by omega
    show cell (1 + (k + P)) 0 = cell (1 + k) 0
    rw [show 1 + (k + P) = (1 + k) + P by omega]
    exact hper (1 + k) this
  have hnot := Rule30DrivenLeft.col_neg_one_not_periodic (c := fun k => cell (1 + k) 0)
    (s := fun p => cell 1 p) (m := 1) (Rule30DrivenLeft.real_edge 1).1 (Rule30DrivenLeft.real_edge 1).2
    (by omega) hc1
  intro hper
  apply hnot
  have heq : (fun k => Rule30DrivenLeft.L (fun k => cell (1 + k) 0) (fun p => cell 1 p) k (-1)) =
      (fun k => cell (1 + k) (-1)) := by
    funext k
    exact Rule30DrivenLeft.cell_eq_L 1 k (-1) (by omega)
  rwa [heq]

/-- Erica Jen's Local Spatial Inversion Law:
    Every cell at position x - 1 and time t is uniquely determined by the future cell (t+1, x)
    and the local neighborhood (t, x) and (t, x+1):
    c(t, x - 1) = c(t + 1, x) ⊕ (c(t, x) ∨ c(t, x + 1)).
    This guarantees that two periodic columns uniquely constrain all columns to their left. -/
theorem jen_spatial_inversion_law (t : Nat) (x : Int) :
    cell t (x - 1) = xor (cell (t + 1) x) (cell t x || cell t (x + 1)) :=
  cell_left t x

/-- Jen's Theorem for the Single Seed: At most one column in the entire CA is eventually periodic. -/
theorem single_column_periodicity_bound (j k : Int)
    (hj : EventuallyPeriodic (fun t => cell t j))
    (hk : EventuallyPeriodic (fun t => cell t k)) : j = k :=
  periodic_column_unique j k hj hk

/-- Diagonal Horizon Principle: Every black center cell lies strictly in the first period of its right diagonal. -/
theorem center_black_cell_light_cone_barrier (t k : Nat) (hc : cell t 0 = true) (h : Per t (2 ^ k)) :
    t < 2 ^ k :=
  center_black_lt hc h

/-- Problem 3 implies Problem 1: Any computational lower bound n^o(1) proves aperiodicity. -/
theorem problem1_of_robust_problem3 (h : Rule30Problem3.Problem3Robust) :
    Rule30Prize.Problem1 :=
  Rule30Equivalents.ProblemThree.problem1_of_problem3Robust h

/-- Progression Equidistribution implies Problem 1: Density 1/2 along arithmetic progressions rules out any periodic orbit. -/
theorem problem1_of_progression_density
    (h : ∀ P r : ℕ, 0 < P → Filter.Tendsto (fun n : ℕ =>
      (((Finset.range n).filter fun k => center (r + k * P) = true).card : ℝ) / n) Filter.atTop (nhds (1 / 2))) :
    Rule30Prize.Problem1 :=
  Rule30Equivalents.ProblemTwo.problem1_of_density_on_progressions h

/-- Unbounded Algebraic Degree implies Problem 1: No NFSR of bounded degree k >= 1 can generate the center column. -/
theorem problem1_of_unbounded_algebraic_degree {k : ℕ} (hk : 1 ≤ k)
    (h : ∀ m, ¬ ∃ F : (Fin m → Bool) → Bool, Rule30Equivalents.AlgebraicDegree.DegreeLE k F ∧ ∀ i, center (i + m) = F fun j => center (i + j)) :
    Rule30Prize.Problem1 :=
  (Rule30Equivalents.AlgebraicDegree.problem1_iff_no_feedback_degreeLE hk).2 h

/-- Büchi Monadic Transcendence implies Problem 1: The black times are not definable both in (N, +, V_2) and (N, +, V_3). -/
theorem problem1_of_not_buchi_definable (A : Set ℕ)
    (h : ¬ (A.Definable₁ (Rule30Equivalents.BuchiArithmetic.buchi 2) {t | center t = true} ∧
           A.Definable₁ (Rule30Equivalents.BuchiArithmetic.buchi 3) {t | center t = true})) :
    Rule30Prize.Problem1 :=
  (Rule30Equivalents.BuchiArithmetic.problem1_iff_not_buchi_definable A).2 h

/-- Cobham Dual Automaticity Transcendence implies Problem 1: The center column is not both 2- and 3-automatic. -/
theorem problem1_of_not_two_three_automatic
    (h : ¬ (Rule30Equivalents.Automatic.IsAutomatic 2 center ∧ Rule30Equivalents.Automatic.IsAutomatic 3 center)) :
    Rule30Prize.Problem1 :=
  Rule30Equivalents.Cobham.problem1_iff_not_two_three_automatic.2 h

/-- Disagreement Invariance implies Problem 1: If the center column disagrees infinitely often with every shifted copy, it is aperiodic. -/
theorem problem1_of_disagreements
    (h : ∀ τ, 0 < τ → {t | center t ≠ center (t + τ)}.Infinite) :
    Rule30Prize.Problem1 :=
  Rule30Equivalents.StrongerStatements.problem1_of_infinite_disagreements h

/-- Positive Besicovitch Distance implies Problem 1: The center column differs infinitely often from every periodic sequence. -/
theorem problem1_of_positive_besicovitch_distance
    (h : ∀ (y : ℕ → Bool) (P : ℕ), 0 < P → (∀ t, y (t + P) = y t) → {t | center t ≠ y t}.Infinite) :
    Rule30Prize.Problem1 :=
  Rule30Equivalents.StrongerStatements.problem1_of_far_from_periodic h

/-- Grand Headline Theorem: Left diagonal ladder dynamics, driven boundary non-periodicity, Jen column uniqueness, and Problem 1-2-3 bridge reductions. -/
theorem grand_structural_invariants :
    (∀ t, 2 ≤ t → D 2 t = false) ∧
    (∀ t, 2 ≤ t → D 3 (t + 2) = D 3 t) ∧
    (∀ t, 4 ≤ t → D 4 t = true) ∧
    (∀ t, 5 ≤ t → D 5 t = D 3 t) ∧
    (∀ t, 5 ≤ t → D 5 (t + 2) = D 5 t) ∧
    (∀ t, 6 ≤ t → D 6 t = D 5 t) ∧
    (∀ t, 6 ≤ t → D 6 (t + 2) = D 6 t) ∧
    (∀ t, 7 ≤ t → D 7 t = false) ∧
    (¬ ∃ N, ∀ t, N ≤ t → center (t + 1) = center t) ∧
    (∀ j k : Int, EventuallyPeriodic (fun t => cell t j) → EventuallyPeriodic (fun t => cell t k) → j = k) ∧
    (Rule30Problem3.Problem3Robust → Rule30Prize.Problem1) ∧
    ((∀ P r : ℕ, 0 < P → Filter.Tendsto (fun n : ℕ =>
      (((Finset.range n).filter fun k => center (r + k * P) = true).card : ℝ) / n) Filter.atTop (nhds (1 / 2))) → Rule30Prize.Problem1) ∧
    ((¬ (Rule30Equivalents.Automatic.IsAutomatic 2 center ∧ Rule30Equivalents.Automatic.IsAutomatic 3 center)) → Rule30Prize.Problem1) ∧
    ((∀ τ, 0 < τ → {t | center t ≠ center (t + τ)}.Infinite) → Rule30Prize.Problem1) ∧
    ((∀ (y : ℕ → Bool) (P : ℕ), 0 < P → (∀ t, y (t + P) = y t) → {t | center t ≠ y t}.Infinite) → Rule30Prize.Problem1) :=
  ⟨D_two_ge_two, D_three_period_two, D_four_ge_four, D_five_ge_five, D_five_period_two,
   D_six_ge_six, D_six_period_two, D_seven_ge_seven, no_period_one, single_column_periodicity_bound,
   problem1_of_robust_problem3, problem1_of_progression_density, problem1_of_not_two_three_automatic,
   problem1_of_disagreements, problem1_of_positive_besicovitch_distance⟩

end Rule30Submission
